function NumberSummationUsingFor() {
  var i, sumFor = 0;

  for(i=1; i<=1000;i++) {
    sumFor = sumFor + i;
  }
  console.log("Sum of 1000 numbers using For loop is: " + sumFor);
};

function NumberSummationUsingWhile() {
  var j=0, sumWhile = 0;

  while (j<=1000) {
    sumWhile = sumWhile + j;
    j++;
  }
  console.log("Sum of 1000 numbers using While loop is: " + sumWhile);
};
